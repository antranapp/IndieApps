# ContentTools

## Running `ContentTools

```swift
swift run --package-path scripts/ContentTools ContentTools
```
